package edu.senai.br.projetosaiot;

/**
 *
 * @author camila_alves3
 */
public class ProjetoSaIoT {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
